URL = "http://www.doc.alabama.gov/inmatesearch"

LOGIN = "root"
PASSWORD = "root"
IP = "127.0.0.1"
PORT = 3306
DB_NAME = "admin_offrec"
TABLE_NAME = "test_clear"


# CREATE_TABLE = f'CREATE TABLE {TABLE_NAME} (    \
#                 state TEXT,                     \
#                 ais INT(8) PRIMARY KEY,         \
#                 inmate TEXT,                    \
#                 institution TEXT,               \
#                 bio TEXT,                       \
#                 aliases TEXT,                   \
#                 scars TEXT,                     \
#                 photo_url TEXT,                 \
#                 catalog_photo TEXT,             \
#                 incarceration_details TEXT      \
#             )'
CREATE_TABLE = f'CREATE TABLE {TABLE_NAME} (            \
        State TEXT,				        \
        Ais INT(10) PRIMARY KEY,		        \
        Inmate TEXT,				        \
        Institution TEXT,			        \
        Race TEXT,				        \
        Sex TEXT,					\
        Hair TEXT,			                \
        Eye TEXT,					\
        Height TEXT,					\
        Weight TEXT,					\
        Brith_Year TEXT,				\
        Custody TEXT,					\
        Aliases TEXT,					\
        Scars TEXT,					\
        Photo_url TEXT,					\
        Catalog_photo TEXT,                             \
        Suf TEXT,					\
        Admit_Date TEXT,				\
        Total_Term TEXT,				\
        Time_Served TEXT,				\
        Jail_Credit TEXT,				\
        Good_Time_Received TEXT,			\
        Good_Time_Revoked TEXT,				\
        Min_Release_Date TEXT,				\
        Parole_Consideration_Date TEXT,			\
        Parole_Status TEXT,				\
        Cas_No TEXT,					\
        Sentenced TEXT,					\
        Offense TEXT,					\
        Term TEXT,					\
        Type TEXT,					\
        Commit_County TEXT				\
    )'

DELETE_DUBLICATE =f"ALTER IGNORE TABLE {TABLE_NAME} ADD UNIQUE INDEX(ais)"