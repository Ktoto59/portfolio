from bs4 import BeautifulSoup
from selenium.common.exceptions import NoSuchElementException
from mysql.connector import connect, Error
import mysql.connector
from selenium import webdriver
import string
import re
from progress.bar import IncrementalBar
import requests
import os
import time
from config import URL, LOGIN, PASSWORD, IP, PORT, DB_NAME, TABLE_NAME, CREATE_TABLE


def enter_key():
    print("Get ID in Ais.txt")
    for i in string.ascii_uppercase:
        element = driver.find_element("id", "MainContent_txtFName")
        element.send_keys(i)
        element.submit()
        element = driver.find_element("name", "ctl00$MainContent$btnSearch")
        element.click()
        try:
            page = driver.page_source
            match = re.findall(r'\b\d{8}\b', str(page))
            for n in range(match.__len__()):
                file = open('Ais.txt', 'a')
                file.write(match[n])
                file.write('\n')
            try:
                pagination = driver.find_element("id", "MainContent_gvInmateResults_lblPages").text
                bar2 = IncrementalBar("Key: " + i + " Pagination", max=int(pagination))
                for e in range(int(pagination) - 1):
                    bar2.next()
                    element = driver.find_element("id", "MainContent_gvInmateResults_btnNext")
                    element.click()
                    id_offender = driver.page_source
                    match = re.findall(r'\b\d{8}\b', str(id_offender))
                    bar2.finish()
                    for a in range(match.__len__()):
                        file = open('Ais.txt', 'a')
                        file.write(match[a])
                        file.write('\n')
                else:
                    bar2.finish()
                    element = driver.find_element("id", "MainContent_btnSearchAgain")
                    element.click()
            except NoSuchElementException:
                element = driver.find_element("id", "MainContent_btnSearchAgain")
                element.click()
        except NoSuchElementException:
            element = driver.find_element("id", "MainContent_btnSearchAgain")
            element.click()


def enter_ais():
    with open("Ais.txt", "r") as file:
        old = file.readlines()
        bar = IncrementalBar(max=len(old))
        try:
            for item in old:
                option = webdriver.ChromeOptions()
                option.add_argument('headless')
                option.add_argument('--log-level=3')
                option.add_experimental_option('excludeSwitches', ['enable-logging'])
                driver = webdriver.Chrome(chrome_options=option)
                driver.get(URL)
                time.sleep(1)
                p3 = item[-2]           # Photo dir
                p2 = item[-3]           # Photo dir
                p1 = item[-4]           # Photo dir
                bar.next()
                bar.finish()
                element = driver.find_element("id", "MainContent_txtAIS")
                element.send_keys(item)
                try:
                    element = driver.find_element("id", "MainContent_gvInmateResults_lnkInmateName_0")
                    element.click()
                    time.sleep(1)
                    page = driver.page_source
                    soup = BeautifulSoup(page, 'lxml')
                    inmate = soup.find('span', id='MainContent_DetailsView2_Label1').text.strip()
                    ais = soup.find('span', id='MainContent_DetailsView2_Label2').text.strip()
                    institution = soup.find('span', id='MainContent_DetailsView2_Label3').text.strip()
                    try:
                        image_path = 'img'
                        if not os.path.exists(image_path):
                            os.mkdir(image_path)
                        if not os.path.exists(image_path + "\\" + p1):
                            os.mkdir(image_path + "\\" + p1)
                        if not os.path.exists(image_path + "\\" + p1 + "\\" + p2):
                            os.mkdir(image_path + "\\" + p1 + "\\" + p2)
                        if not os.path.exists(image_path + "\\" + p1 + "\\" + p2 + "\\" + p3):
                            os.mkdir(image_path + "\\" + p1 + "\\" + p2 + "\\" + p3)
                        photo_dir = str(image_path + "/" + p1 + "/" + p2 + "/" + p3)
                        img = driver.find_element("id", "MainContent_imgInmate").get_attribute("src")
                        p = requests.get(img)
                        out = open(image_path + "\\" + p1 + "\\" + p2 + "\\" + p3 + "\\"
                                   + ais + '.jpg', "wb")
                        out.write(p.content)
                        out.close()
                    except:
                        print('Элемент не найден')
                    try:
                        race = soup.find('table', id="MainContent_DetailsView1").find_all('td')[0].text
                        race1 = soup.find('table', id="MainContent_DetailsView1").find_all('td')[1].text.strip()
                        sex = soup.find('table', id="MainContent_DetailsView1").find_all('td')[2].text
                        sex1 = soup.find('table', id="MainContent_DetailsView1").find_all('td')[3].text.strip()
                        hair = soup.find('table', id="MainContent_DetailsView1").find_all('td')[4].text
                        hair1 = soup.find('table', id="MainContent_DetailsView1").find_all('td')[5].text.strip()
                        eye = soup.find('table', id="MainContent_DetailsView1").find_all('td')[6].text
                        eye1 = soup.find('table', id="MainContent_DetailsView1").find_all('td')[7].text.strip()
                        height = soup.find('table', id="MainContent_DetailsView1").find_all('td')[8].text
                        height1 = soup.find('table', id="MainContent_DetailsView1").find_all('td')[9].text.strip()
                        weight = soup.find('table', id="MainContent_DetailsView1").find_all('td')[10].text
                        weight1 = soup.find('table', id="MainContent_DetailsView1").find_all('td')[11].text.strip()
                        brith_year = soup.find('table', id="MainContent_DetailsView1").find_all('td')[12].text
                        brith_year1 = soup.find('table', id="MainContent_DetailsView1").find_all('td')[13].text.strip()
                        custody = soup.find('table', id="MainContent_DetailsView1").find_all('td')[14].text
                        custody1 = soup.find('table', id="MainContent_DetailsView1").find_all('td')[15].text.strip()

                        suf = soup.find("tr", align="left").find('a', href="Definitions.aspx#Suffix").text
                        admit_date = soup.find("tr", align="left").find('a', href="Definitions.aspx#AdmitDate").text
                        total_term = soup.find("tr", align="left").find('a', href="Definitions.aspx#TotalTerm").text
                        time_served = soup.find("tr", align="left").find('a', href="Definitions.aspx#TimeServed").text
                        jail_credit = soup.find("tr", align="left").find('a', href="Definitions.aspx#JailCredit").text
                        good_time_received = soup.find("tr", align="left").find('a', href="Definitions.aspx#GoodTimeReceived").text
                        good_time_revoked = soup.find("tr", align="left").find('a', href="Definitions.aspx#GoodTimeRevoked").text
                        min_release_date = soup.find("tr", align="left").find('a', href="Definitions.aspx#MinimumReleaseDate").text
                        parole_consideration_date = soup.find("tr", align="left").find('a', href="Definitions.aspx#ParoleConsiderationDate").text
                        parole_status = soup.find("tr", align="left").find('a', href="Definitions.aspx#ParoleStatus").text
                        suf_date = soup.find('div').find_all_next("tr", align="left")[1].find_all_next('td')[0].text
                        adm_date = soup.find('div').find_all_next("tr", align="left")[1].find_all_next('td')[1].text
                        total_t = soup.find('div').find_all_next("tr", align="left")[1].find_all_next('td')[2].text
                        time_ser = soup.find('div').find_all_next("tr", align="left")[1].find_all_next('td')[3].text
                        jail_cred = soup.find('div').find_all_next("tr", align="left")[1].find_all_next('td')[4].text
                        good_time_receiv = soup.find('div').find_all_next("tr", align="left")[1].find_all_next('td')[5].text
                        good_time_revok = soup.find('div').find_all_next("tr", align="left")[1].find_all_next('td')[6].text
                        min_release_dat = soup.find('div').find_all_next("tr", align="left")[1].find_all_next('td')[7].text
                        parole_consideration_dat = soup.find('div').find_all_next("tr", align="left")[1].find_all_next('td')[8].text
                        parole_stat = soup.find('div').find_all_next("tr", align="left")[1].find_all_next('td')[9].text
                        cas_no = soup.find('table', id="MainContent_gvSentence_GridView1_0").find('a', href="Definitions.aspx#CaseNumber").text
                        sentenced = soup.find('table', id="MainContent_gvSentence_GridView1_0").find('a', href="Definitions.aspx#SentenceDate").text
                        offense = soup.find('table', id="MainContent_gvSentence_GridView1_0").find('a', href="Definitions.aspx#Offense").text
                        term = soup.find('table', id="MainContent_gvSentence_GridView1_0").find('a', href="Definitions.aspx#Term").text
                        type = soup.find('table', id="MainContent_gvSentence_GridView1_0").find('a', href="Definitions.aspx#Type").text
                        commit_county = soup.find('table', id="MainContent_gvSentence_GridView1_0").find('a', href="Definitions.aspx#CommitCounty").text
                        cas = soup.find('span', id="MainContent_gvSentence_GridView1_0_Label1_0").text
                        sent = soup.find('span', id="MainContent_gvSentence_GridView1_0_Label2_0").text
                        offen = soup.find('span', id="MainContent_gvSentence_GridView1_0_Label3_0").text
                        ter = soup.find('span', id="MainContent_gvSentence_GridView1_0_Label4_0").text
                        typ = soup.find('span', id="MainContent_gvSentence_GridView1_0_Label5_0").text
                        commit = soup.find('span', id="MainContent_gvSentence_GridView1_0_Label6_0").text
                        bio = {
                                race: race1,
                                sex: sex1,
                                hair: hair1,
                                eye: eye1,
                                height: height1,
                                weight: weight1,
                                brith_year: brith_year1,
                                custody: custody1
                              }
                        inc_det = {
                                                    suf: suf_date,
                                                    admit_date: adm_date,
                                                    total_term: total_t,
                                                    time_served: time_ser,
                                                    jail_credit: jail_cred,
                                                    good_time_received: good_time_receiv,
                                                    good_time_revoked: good_time_revok,
                                                    min_release_date: min_release_dat,
                                                    parole_consideration_date: parole_consideration_dat,
                                                    parole_status: parole_stat
                                                }
                        sentences = {
                                        cas_no: cas,
                                        sentenced: sent,
                                        offense: offen,
                                        term: ter,
                                        type: typ,
                                        commit_county: commit
                                    }
                    except:
                        print('Нет данных')
                    try:
                        aliases = driver.find_element("id", "MainContent_lvAlias_AliasLabel0_0").text
                    except:
                        print('Нет прозвища')
                    try:
                        scars = driver.find_element("id", "MainContent_lvScars_descriptLabel_0").text
                    except:
                        print('Нет особых отметок')
                    driver.close()
                    try:
                        with mysql.connector.connect(
                                host=IP,
                                port=PORT,
                                user=LOGIN,
                                password=PASSWORD,
                                database=DB_NAME
                        ) as connection:
                            with connection.cursor() as cursor:
                                try:
                                    sql = str(f"INSERT INTO {TABLE_NAME} (State, Ais, Inmate, Institution, Race, Sex,"
                                              f" Hair, Eye, Height, Weight, Brith_Year, Custody, Aliases, Scars,"
                                              "Photo_url, Catalog_photo, Suf, Admit_Date, Total_Term, Time_Served,"
                                              "Jail_Credit, Good_Time_Received, Good_Time_Revoked, Min_Release_Date,"
                                              "Parole_Consideration_Date, Parole_Status, Cas_No, Sentenced, Offense,"
                                              "Term, Type, Commit_County) "
                                              "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,"
                                              "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)")
                                    val = (
                                    'AL', ais, inmate, institution, bio[race], bio[sex], bio[hair], bio[eye],
                                    bio[height], bio[weight], bio[brith_year], bio[custody], aliases, scars,
                                    img, photo_dir + '/' + ais + ".jpg", inc_det[suf], inc_det[admit_date],
                                    inc_det[total_term], inc_det[time_served], inc_det[jail_credit],
                                    inc_det[good_time_received], inc_det[good_time_revoked], inc_det[min_release_date],
                                    inc_det[parole_consideration_date], inc_det[parole_status], sentences[cas_no],
                                    sentences[sentenced], sentences[offense], sentences[term], sentences[type],
                                    sentences[commit_county],)
                                    cursor.execute(sql, val)
                                    connection.commit()
                                except Error:
                                    print(f'Ошибка при записи {ais}')
                    except:
                        print(f'Ошибка подключения к БД: {Error}')
                except:
                    driver.close()
        except Error:
            pass


def chek_db():
     try:
        with mysql.connector.connect(
                host=IP,
                user=LOGIN,
                password=PASSWORD,
                database=DB_NAME,
                port=PORT
        ) as connection:
            with connection.cursor() as cursor:
                try:
                    cursor.execute(CREATE_TABLE)
                    connection.commit()
                    connection.close()
                except:
                    connection.close()
     except Error:
        with mysql.connector.connect(
                    host=IP,
                    user=LOGIN,
                    password=PASSWORD,
                    port=PORT
                ) as connection:
                    with connection.cursor() as cursor:
                        try:
                            cursor.execute("CREATE DATABASE " + DB_NAME)
                            connection.commit()
                            print(f'БД {DB_NAME} создана')
                        except Error:
                            connection.close()
     finally:
        try:
            with mysql.connector.connect(
                    host=IP,
                    user=LOGIN,
                    password=PASSWORD,
                    database=DB_NAME,
                    port=PORT
            ) as connection:
                with connection.cursor() as cursor:
                    try:
                        cursor.execute(CREATE_TABLE)
                        connection.commit()
                        print(f'Таблица {TABLE_NAME} создана')
                        connection.close()
                    except Error:
                        connection.close()
                        print(f'Таблица {TABLE_NAME} уже существует')
        except Error:
            print(f'Ошибка подключения к БД: {Error}')


if __name__ == '__main__':
    while True:
        try:
            print('1 - Загрузить все ID в файл Ais.txt')
            print('2 - Загрузить данные по списку ID из файла Ais.txt')
            choise = input('Выбери цифру нужного варианта: ')
            if choise == str("1"):
                option = webdriver.ChromeOptions()
                option.add_argument('headless')
                option.add_argument('--log-level=3')
                option.add_experimental_option('excludeSwitches', ['enable-logging'])
                driver = webdriver.Chrome(chrome_options=option)
                driver.get(URL)
                enter_key()
                driver.close()
            elif choise == str("2"):
                chek_db()
                enter_ais()
        except ValueError:
            print('Введите число!')
        except KeyboardInterrupt:
            print(' ')
            print('Программа закрывается')
            time.sleep(1)
            exit()
